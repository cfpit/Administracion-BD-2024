-- Copia de Seguridad Full Backup
BACKUP DATABASE [pubs]
To DISK='c:\backups\pubs.bak'
WITH FORMAT,
MEDIANAME = 'Pubs',
NAME = 'Full-Pubs backup';

--Si el medio de almacenamiento ya contiene datos (por ejemplo, si el archivo de respaldo .bak ya existe), usar WITH FORMAT borrar� todos los datos existentes en ese medio antes de comenzar el respaldo. Esto asegura que el respaldo no se mezcle con datos antiguos o irrelevantes.

--MEDIANAME = 'Pubs' indica que el respaldo se est� realizando en un medio identificado por el nombre 'Pubs'. Esto podr�a ser simplemente una convenci�n de nomenclatura elegida por el administrador de la base de datos para organizar respaldos.

--NAME = 'Full-Pubs backup' asigna el nombre 'Full-Pubs backup' al respaldo, facilitando su identificaci�n en futuras operaciones de restauraci�n o gesti�n de respaldos.


-- Restauracion de full backup 
RESTORE DATABASE [pubs]
FROM DISK = 'C:\backups\pubs.bak'
WITH REPLACE;

--WITH REPLACE: Esta opci�n permite que la restauraci�n sobrescriba una base de datos existente con el mismo nombre. Si ya existe una base de datos con el nombre especificado y deseas reemplazarla con los datos del respaldo, debes usar REPLACE. Si no deseas reemplazar una base de datos existente, puedes omitir esta opci�n.


-- Respaldo en multiples discos
BACKUP DATABASE pubs TO 
DISK = 'c:\backups\pubs_1.bak', 
DISK = 'c:\backups\pubs_2.bak', 
DISK = 'c:\backups\pubs_3.bak', 
DISK = 'c:\backups\pubs_4.bak' 
WITH INIT, NAME = 'full pubs backup', STATS = 5

--WITH INIT: Este par�metro formatea cada medio de almacenamiento especificado antes de escribir el respaldo. Esto significa que cada uno de los archivos .bak mencionados se inicializar�, borrando cualquier contenido existente.

--STATS = 5: Este par�metro muestra progresos del respaldo cada 5% completado. Es �til para monitorear el progreso del respaldo, especialmente cuando se trabaja con respaldos grandes o m�ltiples discos.


-- Restauracion
RESTORE DATABASE [pubs]
FROM DISK = 'C:\backups\pubs_1.bak',
     DISK = 'C:\backups\pubs_2.bak',
     DISK = 'C:\backups\pubs_3.bak',
     DISK = 'C:\backups\pubs_4.bak'
WITH REPLACE;



-- Copia de Seguridad. Differential Backup
-- Un respaldo diferencial es una t�cnica que captura solo los cambios realizados en la base de datos desde el �ltimo respaldo completo o diferencial. Esto significa que el respaldo diferencial es m�s r�pido y consume menos espacio en disco que un respaldo completo, ya que solo necesita registrar las modificaciones desde el �ltimo respaldo completo.
BACKUP DATABASE [pubs]
To DISK='c:\backups\pubs.bak'
WITH FORMAT,
MEDIANAME = 'Pubs',
NAME = 'Full-Pubs backup';

-- Entre el backup full y el diferencial agreagamos la tabla prueba a la base pubs.
use pubs
go
create table prueba(codigo int)


BACKUP DATABASE [pubs]
   To DISK='c:\backups\pubs_diff.bak'
   WITH DIFFERENTIAL,
    MEDIANAME = 'Native_SQLServerDiffBackup',
    NAME = 'Diff-pubs backup';

-- Restauracion
--Para restaurar una base de datos a partir de un respaldo diferencial, primero debemos restaurar el respaldo completo m�s reciente y luego aplicar el respaldo diferencial.
RESTORE DATABASE [pubs]
FROM DISK = 'c:\backups\pubs.bak'
WITH NORECOVERY;

--WITH NORECOVERY: Cuando se utiliza WITH NORECOVERY en una operaci�n de restauraci�n, SQL Server mantiene la base de datos en un estado donde est� lista para aplicar respaldos de registro de transacciones adicionales. 

RESTORE DATABASE [pubs]
FROM DISK = 'C:\backups\pubs_diff.bak'
WITH RECOVERY;

-- WITH RECOVERY: Se utiliza para indicar que la base de datos debe ser puesta en modo de recuperaci�n normal despu�s de la restauraci�n. Esto significa que la base de datos estar� disponible para operaciones normales inmediatamente despu�s de la restauraci�n.


-- La instrucci�n 
RESTORE FILELISTONLY FROM DISK = 'C:\backups\pubs.bak' 

--en SQL Server se utiliza para listar los archivos de datos contenidos dentro de un archivo de respaldo sin realmente restaurar los datos. Esta operaci�n es �til para obtener informaci�n sobre los archivos de respaldo sin afectar la base de datos existente ni consumir recursos adicionales.
